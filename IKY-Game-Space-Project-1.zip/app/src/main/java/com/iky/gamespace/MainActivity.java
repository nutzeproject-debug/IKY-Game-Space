package com.iky.gamespace;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.net.*;
import java.util.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(10,12,25), panel = Color.rgb(22,25,48), cyan = Color.rgb(0,240,255), pink = Color.rgb(255,40,180);
    LinearLayout root, body;
    TextView status;
    Handler handler = new Handler();
    Runnable batteryTask;

    public void onCreate(Bundle b) { super.onCreate(b); showHome(); }
    GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(24);
        if (stroke != 0) d.setStroke(2, stroke); return d;
    }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(14,10,14,10); return t;
    }
    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(18,18,18,18); root.setBackgroundColor(bg);
        TextView head = text("⚡ IKY GAME SPACE", 23, cyan); root.addView(head);
        root.addView(text(title, 14, Color.LTGRAY));
        ScrollView sc = new ScrollView(this); body = new LinearLayout(this); body.setOrientation(1); body.setPadding(0,12,0,12);
        sc.addView(body); root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void card(String title, String desc, Runnable action) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(12,10,12,10);
        box.setBackground(shape(panel, pink)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,7,0,7);
        TextView a = text(title,18,cyan), b = text(desc,13,Color.WHITE); box.addView(a); box.addView(b);
        box.setOnClickListener(v -> action.run()); body.addView(box,p);
    }
    void showHome() {
        base("NEON RGB • Gaming dashboard");
        card("🎮 Game Launcher","Buka game yang terpasang",()->showGames());
        card("🌡 Monitor Suhu HP","Lihat suhu baterai perangkat",()->showTemperature());
        card("📡 Monitor Ping","Uji koneksi jaringan ke server publik",()->showPing());
        card("👆 Game Lab","Tes sentuhan dan multi-touch layar",()->showLab());
        card("🫧 Floating Gaming Tools","Tampilkan panel mengambang",()->floating());
        card("🚀 Profil Performa","Mode Hemat, Seimbang, dan Performa (preset panduan)",()->showProfiles());
        card("📊 Monitor FPS","FPS game lain tidak dapat dibaca akurat oleh aplikasi biasa tanpa akses sistem",()->fpsInfo());
        body.addView(text("IKY Game Space • Redmi 13X • Android 8+",12,Color.GRAY));
    }
    void showGames() {
        base("GAME LAUNCHER");
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN); q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(q,0);
        Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        for (ResolveInfo ri: apps) {
            String pkg = ri.activityInfo.packageName, name = String.valueOf(ri.loadLabel(pm));
            if (pkg.equals(getPackageName())) continue;
            card("🎮 "+name,pkg,()->{
                Intent launch=pm.getLaunchIntentForPackage(pkg);
                if(launch!=null) startActivity(launch); else Toast.makeText(this,"Tidak bisa membuka aplikasi",0).show();
            });
        }
        if(apps.isEmpty()) body.addView(text("Tidak ada aplikasi ditemukan.",15,Color.WHITE));
        back();
    }
    void back(){ Button b=new Button(this); b.setText("KEMBALI"); b.setOnClickListener(v->showHome()); body.addView(b); }
    void showTemperature() {
        base("MONITOR SUHU");
        TextView val=text("Membaca sensor baterai…",30,cyan); body.addView(val);
        IntentFilter f=new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent i=registerReceiver(null,f);
        if(i!=null){ int temp=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1); int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1);
            val.setText(temp<0?"Sensor suhu tidak tersedia":String.format(Locale.US,"%.1f °C",temp/10.0));
            body.addView(text("Baterai: "+level+"%",16,Color.WHITE));
            body.addView(text("Catatan: ini suhu baterai, bukan suhu CPU/GPU.",13,Color.LTGRAY));
        } else val.setText("Data sensor tidak tersedia");
        back();
    }
    void showPing() {
        base("MONITOR PING");
        TextView result=text("Tekan MULAI untuk menguji ping.",18,cyan); body.addView(result);
        Button btn=new Button(this); btn.setText("MULAI TES PING"); body.addView(btn);
        btn.setOnClickListener(v->{ result.setText("Menguji…");
            new Thread(()->{ long start=System.currentTimeMillis(); String msg;
                try { Socket s=new Socket(); s.connect(new InetSocketAddress("1.1.1.1",53),3000);
                    long ms=System.currentTimeMillis()-start; s.close(); msg="Ping TCP Cloudflare: "+ms+" ms";
                } catch(Exception e){ msg="Gagal terhubung / jaringan memblokir tes."; }
                final String out=msg; runOnUiThread(()->result.setText(out));
            }).start();
        }); back();
    }
    void showLab() {
        base("GAME LAB • TOUCH TEST");
        body.addView(text("Sentuh area di bawah. Titik dan jumlah jari akan ditampilkan.",14,Color.WHITE));
        TouchPad pad=new TouchPad(this); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,520); body.addView(pad,p); back();
    }
    class TouchPad extends View {
        android.graphics.Paint paint=new android.graphics.Paint(3); String label="Sentuhan: 0";
        TouchPad(Context c){super(c);setBackground(shape(panel,cyan));}
        protected void onDraw(android.graphics.Canvas c){super.onDraw(c); paint.setColor(cyan);paint.setTextSize(34);c.drawText(label,24,55,paint);
            paint.setColor(pink);paint.setTextSize(22);c.drawText("Area tes layar sentuh",24,95,paint);}
        public boolean onTouchEvent(android.view.MotionEvent e){label="Sentuhan aktif: "+e.getPointerCount();invalidate();return true;}
    }
    void floating() {
        if(!Settings.canDrawOverlays(this)){
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
            startActivity(i); Toast.makeText(this,"Izinkan tampil di atas aplikasi lain, lalu tekan fitur ini lagi.",1).show(); return;
        }
        startService(new Intent(this,FloatingService.class));
        Toast.makeText(this,"Panel mengambang aktif. Ketuk tombol × untuk menutup.",0).show();
    }
    void showProfiles() {
        base("PROFIL PERFORMA");
        card("🔋 Hemat","Kurangi kecerahan dan tutup aplikasi latar belakang.",()->profile("Hemat"));
        card("⚖ Seimbang","Gunakan pengaturan normal untuk bermain harian.",()->profile("Seimbang"));
        card("⚡ Performa","Aktifkan mode performa bawaan perangkat jika tersedia melalui pengaturan Xiaomi.",()->{
            openSettings();
            Toast.makeText(this,"Pilih mode performa dari pengaturan sistem jika tersedia.",1).show();
        });
        card("Buka Pengaturan Baterai","Atur penghematan baterai dari Android.",()->openSettings()); back();
    }
    void profile(String s){ new AlertDialog.Builder(this).setTitle("Profil "+s).setMessage("Preset ini adalah panduan pengaturan. Aplikasi pihak ketiga tidak dapat memaksa CPU/GPU bekerja lebih cepat tanpa akses sistem/root.").setPositiveButton("OK",null).show(); }
    void openSettings(){try{startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS));}catch(Exception e){startActivity(new Intent(Settings.ACTION_SETTINGS));}}
    void fpsInfo(){
        base("MONITOR FPS");
        body.addView(text("FPS game yang sedang berjalan tidak dapat diukur secara akurat oleh aplikasi biasa pada Android standar.",16,Color.WHITE));
        body.addView(text("Gunakan Game Turbo / panel performa bawaan Xiaomi untuk melihat FPS jika perangkat dan game mendukungnya.",14,cyan)); back();
    }
}
