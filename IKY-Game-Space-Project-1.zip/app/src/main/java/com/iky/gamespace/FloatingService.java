package com.iky.gamespace;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.*;
import android.widget.*;
public class FloatingService extends Service {
    WindowManager wm; View bubble;
    public IBinder onBind(Intent i){return null;}
    public void onCreate(){
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        TextView t=new TextView(this); t.setText("IKY  •  ×"); t.setTextColor(Color.WHITE);t.setTextSize(16);t.setPadding(18,12,18,12);
        GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(30,20,65));d.setCornerRadius(50);d.setStroke(3,Color.rgb(0,240,255));t.setBackground(d);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END;p.x=24;p.y=240;
        t.setOnTouchListener(new View.OnTouchListener(){float x,y;int sx,sy;
            public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){x=e.getRawX();y=e.getRawY();sx=p.x;sy=p.y;return true;}
                if(e.getAction()==2){p.x=sx+(int)(x-e.getRawX());p.y=sy+(int)(e.getRawY()-y);wm.updateViewLayout(t,p);return true;}
                if(e.getAction()==1){if(Math.abs(e.getRawX()-x)<12&&Math.abs(e.getRawY()-y)<12)stopSelf();return true;}return true;}});
        bubble=t;wm.addView(bubble,p);
    }
    public void onDestroy(){if(wm!=null&&bubble!=null)wm.removeView(bubble);super.onDestroy();}
}
