# IKY Game Space

Aplikasi Android bergaya Neon RGB untuk Redmi 13X.

## Fitur versi awal
- Game launcher untuk membuka aplikasi/game yang terpasang.
- Monitor suhu baterai (bukan suhu CPU/GPU).
- Tes ping TCP ke Cloudflare DNS (1.1.1.1:53).
- Game Lab untuk tes sentuhan layar dan multi-touch.
- Floating bubble dengan izin tampil di atas aplikasi lain.
- Profil performa berupa panduan/preset; tidak mengubah clock CPU/GPU.
- Halaman informasi FPS. Pengukuran FPS game lain membutuhkan dukungan sistem/Game Turbo.

## Membuat APK tanpa Android Studio
1. Buat repository baru di GitHub bernama `IKY-Game-Space`.
2. Upload seluruh isi folder proyek ini ke repository (bukan folder ZIP-nya).
3. Buka tab **Actions** dan izinkan GitHub Actions bila diminta.
4. Workflow akan membangun `app-debug.apk`. Unduh dari bagian **Artifacts** pada hasil workflow.
5. Untuk membuat halaman **Releases**: buka **Releases > Draft a new release**, buat tag misalnya `v1.0.0`, lalu publish. Workflow juga otomatis melampirkan APK ke Release saat tag `v*` didorong.

## Catatan perangkat
- Target compile SDK 35, minimum Android 8.0.
- Untuk game launcher, aplikasi meminta daftar aplikasi yang terpasang.
- Floating tools membutuhkan izin **Display over other apps**.
- Aplikasi tidak meminta root dan tidak menjanjikan peningkatan FPS palsu.
- APK debug cocok untuk uji coba. Untuk distribusi luas, buat APK release yang ditandatangani dengan signing key milik pengembang.
